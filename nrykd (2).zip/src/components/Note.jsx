import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Java and React.js</h1>
      <p>
        This Was an amazing bootcamp taken up by shurya sir we coverd Everything
        from scratch including javascript Reacts.js,Html.
      </p>
    </div>
  );
}

export default Note;